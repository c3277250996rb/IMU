/*
 * main.h
 *
 *  Created on: Jul 29, 2024
 *      Author: liu
 */

#ifndef SRC_MAIN_H_
#define SRC_MAIN_H_

#include "CH58x_common.h"
#include <stdint.h>
#include "stdio.h"
#include "stdbool.h"


#endif /* SRC_MAIN_H_ */
