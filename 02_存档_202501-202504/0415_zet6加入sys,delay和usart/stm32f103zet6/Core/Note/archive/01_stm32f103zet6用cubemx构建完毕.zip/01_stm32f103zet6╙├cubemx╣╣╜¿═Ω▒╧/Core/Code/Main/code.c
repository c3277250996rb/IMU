#include "code.h"


void CODE_MAIN(void){
    CODE_INIT();
    CODE_SELF_TEST();
    CODE_WHILE();
}


void CODE_INIT(void){

}

void CODE_SELF_TEST(void){
    printf("�����ɹ�!\r\n");
    printf("����-F103-��Ӣ\r\n");
    while(1){
        
    }
}

void CODE_WHILE(void){

    while(1){

    }
}










