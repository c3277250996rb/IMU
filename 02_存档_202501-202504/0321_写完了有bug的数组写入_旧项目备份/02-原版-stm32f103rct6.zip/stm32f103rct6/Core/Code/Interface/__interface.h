#ifndef __INTERFACE_H
#define __INTERFACE_H

    #include "main.h"

    #include <stdbool.h>
    #include <stdio.h>
    #include <string.h>
    #include <math.h>


#endif // !__INTERFACE_H 
