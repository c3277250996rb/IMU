#include "code.h"
#include "ff.h"

typedef struct __DM_Result_Struct
{
    uint8_t Status;
}DM_Result_Struct;

extern DM_Result_Struct DM_Result_default;

// app
DM_Result_Struct DM_Write(float* input_Array);

// driver


//
int get_row(float* arr);
int get_column(float* arr);
