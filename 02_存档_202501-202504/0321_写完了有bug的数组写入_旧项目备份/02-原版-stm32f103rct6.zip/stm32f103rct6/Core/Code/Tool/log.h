#include "my_tool.h"

#define LOG(my_string, my_int) {printf("[%s][%d]\r\n", my_string, my_int);}
