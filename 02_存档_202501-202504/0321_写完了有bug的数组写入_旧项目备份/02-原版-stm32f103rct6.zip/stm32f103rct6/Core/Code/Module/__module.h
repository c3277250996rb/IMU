#ifndef __MODULE_H
#define __MODULE_H


    #include "my_i2c.h"
    #include "multi_printf.h"

#endif // !__MODULE_H    

