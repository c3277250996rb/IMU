#include "quaternion.h"
#include "data_management.h"

extern float SJ_Array_Roll[Max_Q_Row];
extern float SJ_Array_Pitch[Max_Q_Row];
extern int SJ_Counter;


void search_min_max(void);

void judge_scene(void);

void ReInit_SJ_Array_And_Counter(void);
