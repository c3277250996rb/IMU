#include "main.h"


void reset_array_INT(int len, int *pointer);

void reset_array_FLOAT(int len, float *pointer);



