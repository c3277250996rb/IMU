function output = data2plot(input_s)
    
end