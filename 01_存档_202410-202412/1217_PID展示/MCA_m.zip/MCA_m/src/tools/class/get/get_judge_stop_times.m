function output_get = get_judge_stop_times()
    output_get = public_variable('get_judge_stop_times');
end