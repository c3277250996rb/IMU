function output_get = get_com_number()
    output_get = public_variable('get_com_number');
end