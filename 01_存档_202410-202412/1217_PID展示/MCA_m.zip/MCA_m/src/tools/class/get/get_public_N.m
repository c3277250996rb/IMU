function output_get = get_public_N()
    output_get = public_variable('get_public_N');
end