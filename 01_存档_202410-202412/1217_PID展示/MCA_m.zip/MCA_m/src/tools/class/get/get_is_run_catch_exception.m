function output_get = get_is_run_catch_exception()
    output_get = public_variable('get_is_run_catch_exception');
end