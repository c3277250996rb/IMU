function output_get = get_is_use_uart()
    output_get = public_variable('get_is_use_uart');
end