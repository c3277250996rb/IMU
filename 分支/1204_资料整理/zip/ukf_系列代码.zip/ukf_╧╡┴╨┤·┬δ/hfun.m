function res=hfun(X,k)
    res=X.^2/20;
    end
