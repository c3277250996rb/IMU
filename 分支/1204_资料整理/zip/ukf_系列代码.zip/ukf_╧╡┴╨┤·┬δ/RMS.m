function dist=RMS(X1,X2)
    if length(X2)<=2
        dist=sqrt((X1(1)-X2(1))^2);
    else
        dist=sqrt((X1(1)-X2(1))^2);
    end
    end
    