return:	往返
shake:	震动
single:	单程

fast:	快速
slow:	慢速