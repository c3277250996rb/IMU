function N = public_N()
%     N = 600 - 1;
    N = 800 - 1;
%     N = 1200 - 1;
%     N = 2000 - 1;
    % N = 3000 - 1;
end