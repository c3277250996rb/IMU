#include "my_tool.h"

char* muti_printf_arrays(int num_arrays, const char* delimiter, const char* format, ...);

