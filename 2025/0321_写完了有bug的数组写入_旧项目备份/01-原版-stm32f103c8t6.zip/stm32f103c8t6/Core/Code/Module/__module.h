#ifndef __MODULE_H
#define __MODULE_H


    #include "my_i2c.h"
    #include "muti_printf.h"

#endif // !__MODULE_H    

